/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package table;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class Table extends JTable{
    
    public Table(){
        setShowHorizontalLines(true);
        setGridColor(new Color(230,230,230));
        setRowHeight(40);
        getTableHeader().setReorderingAllowed(false);
        getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public  Component getTableCellRendererComponent(JTable jtable, Object o, boolean bln, boolean bln1, int i, int i1){
            TableHeader header = new TableHeader(o + "");
            
            if(i1 == 4){
                header.setHorizontalAlignment(JLabel.CENTER);
            }
            
            Font centuryGothicFont = new Font("Century Gothic", Font.BOLD, 12);
            header.setFont(centuryGothicFont);
            return header;
            }
        });
        
        
    }
}

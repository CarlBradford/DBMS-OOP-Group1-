
package ngITi_main;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class ConnectionString {
 
    //Create Global variable
    
    //Create method
    public static Connection DbConnection() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull","root","");
            System.out.print("Connected");
            return con;
        }
        catch(HeadlessException | ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, "Database Connection Lost"+e);
            return null;
        }
    }
}
